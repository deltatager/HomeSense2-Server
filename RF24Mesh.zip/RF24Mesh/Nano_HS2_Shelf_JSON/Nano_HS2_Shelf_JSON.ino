#include <Arduino_JSON.h>
#include "RF24.h"
#include "RF24Network.h"
#include "RF24Mesh.h"

#define RED 2
#define GREEN 5
#define BLUE 8
#define LED A0

/**** Configure the nrf24l01 CE and CS pins ****/
RF24 radio(9, 10);
RF24Network network(radio);
RF24Mesh mesh(radio, network);
#define nodeID 5
/**** ****/



void setup() {
  Serial.begin(115200);
  mesh.setNodeID(nodeID);
  Serial.println("Connecting to the mesh...");
  Serial.println(mesh.begin());
  mesh.update();
  pinMode(RED, OUTPUT);
  pinMode(RELAY2, OUTPUT);
  digitalWrite(RELAY1, HIGH);
  digitalWrite(RELAY2, HIGH);
}



void loop() {
  mesh.update();
  
  while (network.available()) {
    char payload[512]{'/0'};
    RF24NetworkHeader header;
    
    int receivedBytes = network.read(header, &payload, sizeof(payload));
    mesh.write(&payload, 'R', receivedBytes, 0);
    JSONVar data = JSON.parse(payload);
    
//    switch((int) data["id"]){
//      case 2: // RELAY 1
//        if(strcmp((const char*) data["mode"], "ON") == 0) {
//          digitalWrite(RELAY1, LOW);
//        } else if (strcmp((const char*) data["mode"], "OFF") == 0) {
//          digitalWrite(RELAY1, HIGH);
//        }
//        break;
//      
//      case 3: // RELAY 2
//        if(strcmp((const char*) data["mode"], "ON") == 0) {
//          digitalWrite(RELAY2, LOW);
//        } else if(strcmp((const char*) data["mode"], "OFF") == 0) {
//          digitalWrite(RELAY2, HIGH);
//        }
//        break;
    }
    
    Serial.println("Data received! Waiting for next command...");
  }
}