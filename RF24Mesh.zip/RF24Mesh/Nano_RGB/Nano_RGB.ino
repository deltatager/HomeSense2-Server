#include "RF24.h"
#include "RF24Network.h"
#include "RF24Mesh.h"

#define RELAY1 2
#define RELAY2 3
#define RELAY3 4
#define RELAY4 5

/**** Configure the nrf24l01 CE and CS pins ****/
RF24 radio(7, 8);
RF24Network network(radio);
RF24Mesh mesh(radio, network);
#define nodeID 2
/**** ****/



void setup() {
  //Reset every output at boot
  analogWrite(REDPIN, 0);
  analogWrite(GREENPIN, 0);
  analogWrite(BLUEPIN, 0);

  Serial.begin(9600);
  // Set the nodeID manually
  mesh.setNodeID(nodeID);
  // Connect to the mesh
  Serial.println(F("Connecting to the mesh..."));
  Serial.println(mesh.begin());
  pinMode(REDPIN, OUTPUT);
  pinMode(GREENPIN, OUTPUT);
  pinMode(BLUEPIN, OUTPUT);
}



void loop() {

  mesh.update();

  while (network.available()) {
    RF24NetworkHeader header;
    network.read(header, &payload, sizeof(payload));
    memcpy(&data, &payload, sizeof(payload));
    
  switch (data.cmd) {
    case 0x2:
      analogWrite(REDPIN, data.r);
      analogWrite(GREENPIN, data.g);
      analogWrite(BLUEPIN, data.b);
      break;
    default:
      Serial.println("Unrecognized data.cmd");
      break;
  }  
    
  
    Serial.println("Received packet!");
    Serial.println("Payload: " + payload);
    Serial.println("Chars: " + (String)data.id + " " + (String)data.cmd + " " + (String)data.r + " " + (String)data.g + " " + (String)data.b);
    Serial.println("Waiting...");
  }
}