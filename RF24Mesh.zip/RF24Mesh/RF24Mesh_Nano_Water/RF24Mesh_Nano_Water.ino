#include "RF24.h"
#include "RF24Network.h"
#include "RF24Mesh.h"

/**** Configure the nrf24l01 CE and CS pins ****/
RF24 radio(3, 4);
RF24Network network(radio);
RF24Mesh mesh(radio, network);

#define nodeID 2

uint16_t raw;
uint16_t hum;
uint32_t payload;
char conf[6] = {"Done\n"};
char bad[6] = {"Bad!\n"};
char arg[6] = {"Arg!\n"};
char h[5];

void setup() {

  Serial.begin(115200);
  //printf_begin();
  // Set the nodeID manually
  mesh.setNodeID(nodeID);
  // Connect to the mesh
  Serial.println(F("Connecting to the mesh..."));
  Serial.println(mesh.begin());
  pinMode(A0, INPUT);
  pinMode(A1, INPUT);
  pinMode(A2, INPUT);
  pinMode(2, OUTPUT);
  pinMode(3, OUTPUT);
  pinMode(4, OUTPUT);
}



void loop() {

  mesh.update();

  while (network.available()) {
    RF24NetworkHeader header;
    network.read(header, &payload, sizeof(payload));
    
    unsigned char bytes[4] ; // long enough for 16 bit integer, 4 digits.
    bytes[0] = (payload >> 24) & 0xFF;
    bytes[1] = (payload >> 16) & 0xFF;
    bytes[2] = (payload >> 8) & 0xFF;
    bytes[3] = payload & 0xFF;
    
    switch (bytes[0]) {
    case 0x40:
      
      switch (bytes[1]) {
      case 0x01:
        digitalWrite(4, HIGH);
        delay(500);
        raw = analogRead(A1);
        digitalWrite(4, LOW);
        hum = map(raw,1006,215,0,100);
        Serial.print("Raw : ");
        Serial.println(raw);
        Serial.print("hum : ");
        Serial.println(hum);
        break;
      case 0x02:
        digitalWrite(3, HIGH);
        delay(500);
        raw = analogRead(A2);
        digitalWrite(3, LOW);
        hum = map(raw,925,210,0,100);
        Serial.print("Raw : ");
        Serial.println(raw);
        Serial.print("hum : ");
        Serial.println(hum);
        break;
      case 0x03:
        digitalWrite(2, HIGH);
        delay(500);
        raw = analogRead(A3); 
        digitalWrite(2, LOW);
        hum = map(raw,890,230,0,100);
        Serial.print("Raw : ");
        Serial.println(raw);
        Serial.print("hum : ");
        Serial.println(hum);
        break;
      default:
        mesh.write(&arg, 'R', sizeof(arg));
        break;
      
      }
      sprintf(h,"%04hu\n", hum);
      mesh.write(&h, 'R', sizeof(h));
      hum = 0;
      break;
    default:
      mesh.write(&bad, 'R', sizeof(bad));
      break;
    }
    
    char b[8];
    sprintf(b,"%08lX", payload);
    Serial.print("Received packet ");
    Serial.println(b);
    Serial.println("Waiting...");
  }
}






