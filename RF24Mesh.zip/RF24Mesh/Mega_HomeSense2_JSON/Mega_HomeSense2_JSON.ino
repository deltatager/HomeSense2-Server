#include <Arduino_JSON.h>
//#include <EEPROM.h>
#include "RF24.h"
#include "RF24Network.h"
#include "RF24Mesh.h"

#define REDPIN 9
#define GREENPIN 10
#define BLUEPIN 11
#define LEDPIN 12

/**** Configure the nrf24l01 CE and CS pins ****/
RF24 radio(7, 8);
RF24Network network(radio);
RF24Mesh mesh(radio, network);
#define nodeID 1
/**** ****/

void setup() {
  Serial.begin(9600);
  mesh.setNodeID(nodeID);
  Serial.println("Connecting to the mesh...");
  Serial.println(mesh.begin());
  pinMode(REDPIN, OUTPUT);
  pinMode(GREENPIN, OUTPUT);
  pinMode(BLUEPIN, OUTPUT);
  pinMode(LEDPIN, OUTPUT);
  
  //Set every output to last known state at boot
  //analogWrite(REDPIN, EEPROM.read(REDPIN));
  //analogWrite(GREENPIN, EEPROM.read(GREENPIN));
  //analogWrite(BLUEPIN, EEPROM.read(BLUEPIN));
  //analogWrite(LEDPIN, EEPROM.read(LEDPIN));
}



void loop() {
  mesh.update();

  while (network.available()) {
    char payload[4096]{'/0'};
    RF24NetworkHeader header;
    
    int receivedBytes = network.read(header, &payload, sizeof(payload));
    String recvString{payload};
    mesh.write(&payload, 'R', receivedBytes, 0);
    JSONVar data = JSON.parse(recvString);
    
    switch((int) data["id"]){
      case 1: //RGB
        if(strcmp((const char*) data["mode"], "ON") == 0) {
          analogWrite(REDPIN, (int) data["red"]);
          //EEPROM.update(REDPIN, (int) data["red"]);
          analogWrite(GREENPIN, (int) data["green"]);
          //EEPROM.update(GREENPIN, (int) data["green"]);
          analogWrite(BLUEPIN, (int) data["blue"]);
          //EEPROM.update(BLUEPIN, (int) data["blue"]);
        } else if (strcmp((const char*) data["mode"], "OFF") == 0) {
          analogWrite(REDPIN, 0);
          //EEPROM.update(REDPIN, 0);
          analogWrite(GREENPIN, 0);
         //EEPROM.update(GREENPIN, 0);
          analogWrite(BLUEPIN, 0);
         // EEPROM.update(BLUEPIN, 0);
        }
        break;
      
      case 11: // PWM LED
        if(strcmp((const char*) data["mode"], "ON") == 0) {
          analogWrite(LEDPIN, (int) data["brightness"]);
          //EEPROM.update(LEDPIN, (int) data["brightness"]);
        } else if(strcmp((const char*) data["mode"], "OFF") == 0) {
          analogWrite(LEDPIN, 0);
          //EEPROM.update(LEDPIN, 0);
        }
        break;
    }
    
    //Serial debugging output
    //serialDebug(recvString, data);
    Serial.println("Data received! Waiting for next command...");
  }
}

void serialDebug(String recvString,JSONVar data) {
  if (JSON.typeof(data) == "undefined") {
      Serial.println("Parsing input failed!");
    }
  
    Serial.println("Received packet!");
    Serial.println("Payload: " + recvString);
    Serial.println("JSON: ");
    
    JSONVar keys = data.keys();
    
    for (int i = 0; i < keys.length(); i++) {
      JSONVar value = data[keys[i]];

      Serial.print("JSON.typeof(data[");
      Serial.print(keys[i]);
      Serial.print("]) = ");
      Serial.println(JSON.typeof(value));

      Serial.print("data[");
      Serial.print(keys[i]);
      Serial.print("] = ");
      Serial.println(value);

      Serial.println();
    }
}
