#include <Arduino_JSON.h>
#include "RF24.h"
#include "RF24Network.h"
#include "RF24Mesh.h"

#define RED 3
#define GREEN 5
#define BLUE 9
#define LED 6

/**** Configure the nrf24l01 CE and CS pins ****/
RF24 radio(10, 8);
RF24Network network(radio);
RF24Mesh mesh(radio, network);
#define nodeID 5
/**** ****/



void setup() {
  Serial.begin(115200);
  mesh.setNodeID(nodeID);
  Serial.println("Connecting to the mesh...");
  Serial.println(mesh.begin());
  mesh.update();
  pinMode(RED, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(BLUE, OUTPUT);
  pinMode(LED, OUTPUT);
  digitalWrite(RED, LOW);
  digitalWrite(GREEN, LOW);
  digitalWrite(BLUE, LOW);
  digitalWrite(LED, LOW);
}



void loop() {
  mesh.update();
  
  while (network.available()) {
    char payload[512]{'/0'};
    RF24NetworkHeader header;
    
    int receivedBytes = network.read(header, &payload, sizeof(payload));
    mesh.write(&payload, 'R', receivedBytes, 0);
    JSONVar data = JSON.parse(payload);
    
    switch((int) data["id"]){
      case 4: //RGB
        if(strcmp((const char*) data["mode"], "ON") == 0) {
          analogWrite(RED, (int) data["red"]);
          //EEPROM.update(REDPIN, (int) data["red"]);
          analogWrite(GREEN, (int) data["green"]);
          //EEPROM.update(GREENPIN, (int) data["green"]);
          analogWrite(BLUE, (int) data["blue"]);
          //EEPROM.update(BLUEPIN, (int) data["blue"]);
        } else if (strcmp((const char*) data["mode"], "OFF") == 0) {
          analogWrite(RED, 0);
          //EEPROM.update(REDPIN, 0);
          analogWrite(GREEN, 0);
         //EEPROM.update(GREENPIN, 0);
          analogWrite(BLUE, 0);
         // EEPROM.update(BLUEPIN, 0);
        }
        break;
      
      case 5: // PWM LED
        if(strcmp((const char*) data["mode"], "ON") == 0) {
          analogWrite(LED, (int) data["brightness"]);
          //EEPROM.update(LEDPIN, (int) data["brightness"]);
        } else if(strcmp((const char*) data["mode"], "OFF") == 0) {
          analogWrite(LED, 0);
          //EEPROM.update(LEDPIN, 0);
        }
        break;
    }
    
    Serial.println("Data received!");
  }
}