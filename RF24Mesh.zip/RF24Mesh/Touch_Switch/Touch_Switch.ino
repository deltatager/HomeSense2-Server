#include "RF24.h"
#include "RF24Network.h"
#include "RF24Mesh.h"

#define TCHPIN 2

/**** Configure the nrf24l01 CE and CS pins ****/
RF24 radio(7, 8);
RF24Network network(radio);
RF24Mesh mesh(radio, network);
#define nodeID 3
/**** ****/

struct Packet {
	unsigned char b;
	unsigned char g;
	unsigned char r;
	unsigned char cmd : 4;
	unsigned char id : 4;
};

Packet data;
bool state = false;

void setup() {
Serial.begin(115200);
// Set the nodeID manually
mesh.setNodeID(nodeID);
// Connect to the mesh
Serial.println(F("Connecting to the mesh..."));
Serial.println(mesh.begin());
pinMode(TCHPIN, INPUT);
  
data.id = 1;
data.cmd = 1;
data.r = 0;
data.g = 0;
data.b = 0;
}

void loop() {
  mesh.update();
  if(digitalRead(TCHPIN) == HIGH){
    Serial.println("Touched!");
    if (state){
      state = false;
      data.r = 0;
      mesh.write(&data, 'R', sizeof(data), data.id);
    }else{
      state = true;
      data.r = 255;
      mesh.write(&data, 'R', sizeof(data), data.id);
    }
  } else {
    Serial.println("Released...");
  }
  delay(500);
 
}