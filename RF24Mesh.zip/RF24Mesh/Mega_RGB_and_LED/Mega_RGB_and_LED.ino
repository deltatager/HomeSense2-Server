#include "RF24.h"
#include "RF24Network.h"
#include "RF24Mesh.h"

#define REDPIN 9
#define GREENPIN 10
#define BLUEPIN 11
#define LEDPIN 12

/**** Configure the nrf24l01 CE and CS pins ****/
RF24 radio(40, 41);
RF24Network network(radio);
RF24Mesh mesh(radio, network);
#define nodeID 1
/**** ****/

struct Packet {
	unsigned char b;
	unsigned char g;
	unsigned char r;
	unsigned char cmd : 4;
	unsigned char id : 4;
};

Packet data;
uint32_t payload;

void setup() {
  

  Serial.begin(115200);
  // Set the nodeID manually
  mesh.setNodeID(nodeID);
  // Connect to the mesh
  Serial.println(F("Connecting to the mesh..."));
  Serial.println(mesh.begin());
  pinMode(REDPIN, OUTPUT);
  pinMode(GREENPIN, OUTPUT);
  pinMode(BLUEPIN, OUTPUT);
  pinMode(LEDPIN, OUTPUT);
}



void loop() {

  mesh.update();

  while (network.available()) {
    RF24NetworkHeader header;
    network.read(header, &payload, sizeof(payload));
    memcpy(&data, &payload, sizeof(payload));
    
  switch (data.cmd) {
    case 0x1:
      analogWrite(LEDPIN, data.r);
      break;
    case 0x2:
      analogWrite(REDPIN, data.r);
      analogWrite(GREENPIN, data.g);
      analogWrite(BLUEPIN, data.b);
      break;
    default:
      Serial.println("Unrecognized data.cmd");
      break;
  }  
    
  
    Serial.println("Received packet!");
    Serial.print("Int: ");
    Serial.println(payload);
    Serial.print("Chars: ");
    Serial.print(+data.id);
    Serial.print(" ");
    Serial.print(+data.cmd);
    Serial.print(" ");
    Serial.print(+data.r);
    Serial.print(" ");
    Serial.print(+data.g);
    Serial.print(" ");
    Serial.println(+data.b);
    Serial.println("Waiting...");
  }
}