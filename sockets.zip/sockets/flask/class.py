#! /usr/bin/python
# -*- coding:utf-8 -*-


class Rgb:

	def __init__(self):
				self.color = 0
			
class Led:
	def __init__(self):
				self.state = 0			
