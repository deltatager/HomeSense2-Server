import socket, struct, ctypes
 
class PacketBits(ctypes.LittleEndianStructure):
    _fields_ = [
        ("b", ctypes.c_uint8, 8),
        ("g", ctypes.c_uint8, 8),
        ("r", ctypes.c_uint8, 8),
        ("cmd", ctypes.c_uint8, 4),
        ("id", ctypes.c_uint8, 4),
    ]
 
class Packet(ctypes.Union):
    _fields_ = [("bits", PacketBits),
                ("binary_data", ctypes.c_uint32)]

p = Packet()

while True:
	text = input("Enter hex value to send: ")
	p.binary_data = int(text, 16)
	print(p.bits.id, p.bits.cmd, p.bits.r, p.bits.g, p.bits.b)
	fd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	fd.connect(('pi.deltanet.int', 7070))
	payload = struct.pack("!L", p.binary_data)
	fd.send(payload)
	fd.close()
	continue