import ctypes
 
class PacketBits(ctypes.LittleEndianStructure):
    _fields_ = [
        ("b", ctypes.c_uint8, 8),
        ("g", ctypes.c_uint8, 8),
        ("r", ctypes.c_uint8, 8),
        ("cmd", ctypes.c_uint8, 4),
        ("id", ctypes.c_uint8, 4),
    ]
 
class Packet(ctypes.Union):
    _fields_ = [("bits", PacketBits),
                ("binary_data", ctypes.c_uint32)]

p = Packet()
p.binary_data = 285278208
print(p.bits.b, p.bits.g, p.bits.r, p.bits.cmd, p.bits.id)

wait = input("PRESS ENTER TO CONTINUE.")