#! /usr/bin/python3
# -*- coding:utf-8 -*-

from flask import Flask, render_template, request, redirect, url_for
from datetime import date, timedelta
import locale, socket, sys
locale.setlocale(locale.LC_ALL, '')

app = Flask(__name__, static_url_path='/static') 

ledState = 0
ledMode = 0

@app.route('/') 
def index():
	return render_template('index.html', title="Accueil")
    
@app.route('/new') 
def new():
	return render_template('roomlink.html', title="RoomLink")

@app.route('/post', methods=["POST"])
def post():

	error = ''
	try:
		color = request.form['color']
		color = color[1:]
		color = bytes(color, encoding = "ascii")
			
		fd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		fd.connect(('localhost', 6969))
		payload =b"01" + b"52" + color
		fd.send(payload)
		recv = fd.recv(1024)
		fd.close()
		payload = ''
		
		return redirect("/")

	except Exception as e:
		return render_template("index.html", e = e)
        
@app.route('/new/post', methods=["POST"])
def postNew():

	error = ''
	try:
		color = request.form['color']
		color = color[1:]
		color = bytes(color, encoding = "ascii")
			
		fd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		fd.connect(('localhost', 6969))
		payload =b"01" + b"52" + color
		fd.send(payload)
		recv = fd.recv(1024)
		fd.close()
		payload = ''
		
		return redirect("/new")

	except Exception as e:
		return render_template("roomlink.html", e = e)

@app.route('/led/<mode>')
def switch(mode):
	global ledState
	global ledMode
	ledMode = int(mode)
	fd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	
	if ledMode == 0:
		fd.connect(('localhost', 6969))
		fd.send(b"0157000000")
		recv = fd.recv(1024)
		fd.close()
		ledState = 0
	elif ledMode == 1:
		fd.connect(('localhost', 6969))
		fd.send(b"0157010000")
		recv = fd.recv(1024)
		fd.close()
		ledState = 1
	elif ledMode == 3:
		fd.connect(('localhost', 6969))
		fd.send(b"0150000000")
		recv = fd.recv(1024)
		fd.close()
		recv = int(recv)
		if recv <= 500 and state == 0:
			fd.connect(('localhost', 6969))
			fd.send(b"0157010000")
			recv = fd.recv(1024)
			fd.close()
			state = 1
		elif recv > 500 and state == 1:
			fd.connect(('localhost', 6969))
			fd.send(b"0157000000")
			recv = fd.recv(1024)
			fd.close()
			ledState = 0
		
	return redirect("/")
    
@app.route('/new/led/<mode>')
def switchNew(mode):
	global ledState
	global ledMode
	ledMode = int(mode)
	fd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	
	if ledMode == 0:
		fd.connect(('localhost', 6969))
		fd.send(b"0157000000")
		recv = fd.recv(1024)
		fd.close()
		ledState = 0
	elif ledMode == 1:
		fd.connect(('localhost', 6969))
		fd.send(b"0157010000")
		recv = fd.recv(1024)
		fd.close()
		ledState = 1
	elif ledMode == 3:
		fd.connect(('localhost', 6969))
		fd.send(b"0150000000")
		recv = fd.recv(1024)
		fd.close()
		recv = int(recv)
		if recv <= 500 and state == 0:
			fd.connect(('localhost', 6969))
			fd.send(b"0157010000")
			recv = fd.recv(1024)
			fd.close()
			state = 1
		elif recv > 500 and state == 1:
			fd.connect(('localhost', 6969))
			fd.send(b"0157000000")
			recv = fd.recv(1024)
			fd.close()
			ledState = 0
		
	return redirect("/new")
    
#@app.route('/sensors'/)
#def sensors():
#    return render_template("sensors.html", e = e)

	
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
