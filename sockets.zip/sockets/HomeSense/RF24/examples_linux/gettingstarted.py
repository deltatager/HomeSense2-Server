#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function
import time as time_
from RF24 import *
import RPi.GPIO as GPIO

true = True
false = False
#***************** Raspberry Pi ***********************/

# Radio CE Pin, CSN Pin, SPI Speed
# See http:#www.airspayce.com/mikem/bcm2835/group__constants.html#ga63c029bd6500167152db4e57736d0939 and the related enumerations for pin information.

# Setup for GPIO 22 CE and CE0 CSN with SPI Speed @ 4Mhz
radio = RF24(RPI_V2_GPIO_P1_22, BCM2835_SPI_CS0, BCM2835_SPI_SPEED_4MHZ)

# NEW: Setup for RPi B+
#RF24 radio(RPI_BPLUS_GPIO_J8_15,RPI_BPLUS_GPIO_J8_24, BCM2835_SPI_SPEED_8MHZ);

# Setup for GPIO 15 CE and CE0 CSN with SPI Speed @ 8Mhz
#RF24 radio(RPI_V2_GPIO_P1_15, RPI_V2_GPIO_P1_24, BCM2835_SPI_SPEED_8MHZ);

# RPi generic:
#RF24 radio(22,0);

#** RPi Alternate ***/
#Note: Specify SPI BUS 0 or 1 instead of CS pin number.
# See http:#tmrh20.github.io/RF24/RPi.html for more information on usage

#RPi Alternate, with MRAA
#RF24 radio(15,0);

#RPi Alternate, with SPIDEV - Note: Edit RF24/arch/BBB/spi.cpp and  set 'this->device = "/dev/spidev0.0";;' or as listed in /dev
#RF24 radio(22,0);

#***************** Linux (BBB,x86,etc) ***********************/

# See http:#tmrh20.github.io/RF24/pages.html for more information on usage
# See http:#iotdk.intel.com/docs/master/mraa/ for more information on MRAA
# See https:#www.kernel.org/doc/Documentation/spi/spidev for more information on SPIDEV

# Setup for ARM(Linux) devices like BBB using spidev (default is "/dev/spidev1.0" )
#RF24 radio(115,0);

#BBB Alternate, with mraa
# CE pin = (Header P9, Pin 13) = 59 = 13 + 46 
#Note: Specify SPI BUS 0 or 1 instead of CS pin number. 
#RF24 radio(59,0);

#********* User Config *********/
# Assign a unique identifier for this node, 0 or 1
radioNumber = 1

#*******************************/

# Radio pipe addresses for the 2 nodes to communicate.
pipes = [b"1Node",b"2Node"]
millis = lambda: int(round(time_.time() * 1000))
role_ping_out = true
role_pong_back = false
role = role_pong_back
print("RF24/examples/GettingStarted/\n")

  # Setup and configure rf radio
radio.begin()

  # optionally, increase the delay between retries & # of retries
radio.setRetries(15,15)
  # Dump the configuration of the rf unit for debugging
radio.printDetails()


#******** Role chooser ***********/

print("\n ************ Role Setup ***********\n")
input = int(input('Choose a role: Enter 0 for receiver, 1 for transmitter (CTRL+C to exit) '))

if input == 0: 
    print("Role: Pong Back, awaiting transmission ")
else:  
    print("Role: Ping Out, starting transmission ")
    role = role_ping_out

#**********************************/
  # This simple sketch opens two pipes for these two nodes to communicate
  # back and forth.

if  not radioNumber: 
    radio.openWritingPipe(pipes[0])
    radio.openReadingPipe(1,pipes[1])
else:
    radio.openWritingPipe(pipes[1])
    radio.openReadingPipe(1,pipes[0])

radio.startListening()
# forever loop
while 1:
    if role == role_ping_out:
        # First, stop listening so we can talk.
        radio.stopListening()
        # Take the time, and send it.  This will block until complete
        print("Now sending...\n")
        time = millis()
        ok = radio.write(time.to_bytes(time.bit_length(), byteorder='little'))
        if not ok:
            print("failed.\n")
            # Now, continue listening
        radio.startListening()

        # Wait here until we get a response, or timeout (250ms)
        started_waiting_at = millis()
        timeout = False
        while (not radio.available()) and (not timeout):
            if (millis() - started_waiting_at) > 500:
                timeout = True


            # Describe the results
        if timeout:
            print("Failed, response timed out.\n")
        else:
            # Grab the response, compare, and send to debugging spew
            got_time = radio.read(32)

            # Spew it
            print("Got response {} , round-trip delay: {}\n".format(int.from_bytes(got_time, byteorder='little'),millis()-int.from_bytes(got_time, byteorder='little')))
        time_.sleep(1)

        #
        # Pong back role.  Receive each packet, dump it out, and send it back
        #

    if role == role_pong_back:
        
            
        # if there is data ready
        if radio.available():
        
            # Dump the payloads until we've gotten everything
            # Fetch the payload, and see if this was the last one.
            while radio.available():
                got_time = radio.read(32)
            
            radio.stopListening()
                
            radio.write(got_time)

                # Now, resume listening so we catch the next packets.
            radio.startListening()

                # Spew it
            #print("Got payload {}...\n".format(got_time.decode('utf-16le')))
            print(int.from_bytes(got_time, byteorder='little'))
                
            time_.sleep(1) #Delay after payload responded to, minimize RPi CPU time
