from RF24 import *
from RF24Network import *
from RF24Mesh import *
import time as time_

millis = lambda: int(round(time_.time() * 1000))
ack = 0x1234;
displayTimer = 0;
# radio setup for RPi B Rev2: CS0=Pin 24
radio = RF24(RPI_V2_GPIO_P1_22, BCM2835_SPI_CS0, BCM2835_SPI_SPEED_8MHZ)
network = RF24Network(radio)
mesh = RF24Mesh(radio, network)

mesh.setNodeID(0)
mesh.begin()
radio.printDetails()
print("start\n")
while 1:
    mesh.update()
    mesh.DHCP()
    if (millis() - displayTimer >= 1000):
        displayTimer = millis()
        
        print(mesh.write(bytes(ack), 82, 1))
	
    #time_.sleep(0.01)