from RF24 import *
from RF24Network import *
from RF24Mesh import *
import time as time_

# radio setup for RPi B Rev2: CS0=Pin 24
radio = RF24(RPI_V2_GPIO_P1_22, BCM2835_SPI_CS0, BCM2835_SPI_SPEED_8MHZ)
network = RF24Network(radio)
mesh = RF24Mesh(radio, network)

mesh.setNodeID(0)
mesh.begin()
radio.printDetails()

while 1:
    mesh.update()
    mesh.DHCP()

    while network.available():
        print("rcv\n")
        header = RF24NetworkHeader
        network.peek(header)
    
        dat=0
        if(header.type == 'M'):
            # Display the incoming millis() values from the sensor nodes
            network.read(header,dat)
            print("Rcv {} from 0{}\n".format(dat,header.from_node))
        else:
            network.read(header,0,0)
            print("Rcv bad type {} from 0{}\n".format(header.type,header.from_node))
    time_.sleep(1)